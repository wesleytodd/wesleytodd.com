<?php
session_start();
if( isset($_REQUEST['cab_hide_page']) ){
	cab_add_disabled_page($_REQUEST['cab_hide_page']);
}
if( isset($_REQUEST['cab_hide_site']) ){
	$_SESSION['cab_hide_site'] = true;
}

if( cab_is_disabled() || isset($_SESSION['cab_hide_site']) ) {
	cab_disable_adminbar();
}else{
	add_action('after_setup_theme', 'cab_hide_by_users');
	add_action('parse_query', 'cab_hide_by_page');
	add_action('admin_bar_menu', 'cab_adminbar_menu', 1000);
	cab_define_callback();
}

function cab_adminbar_menu(){
	global $wp_admin_bar;
	$wp_admin_bar->add_menu(
		array(	'id' => 'cab-menu',
				'title' => __( 'Admin Bar' ),
				'href' => get_admin_url(null, 'options-general.php?page=custom-adminbar-options-menu')
		)
	);

	$wp_admin_bar->add_menu(
		array(	'parent' => 'cab-menu',
				'id' => 'cab_hide_site',
				'title' => __( 'Hide Site Wide' ),
				'href' => parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH)."?cab_hide_site=true"
		)
	);

	$current_object = get_queried_object();
	if ( empty($current_object) )
		return;
	$wp_admin_bar->add_menu(
		array(	'parent' => 'cab-menu',
				'id' => 'cab_hide_page',
				'title' => __( 'Hide For This Page' ),
				'href' => parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH)."?cab_hide_page=".$current_object->ID
		)
	);
}

function cab_is_disabled(){
	if(get_option('custom-adminbar-enabled') != 'on') {
		return true;
	}else{
		return false;
	}
}

function cab_bump_is_disabled(){
	if(get_option('custom-adminbar-bump') != 'on') {
		return true;
	}else{
		return false;
	}
}

function cab_custom_callback(){
	echo '<style>';
	if(!cab_bump_is_disabled()){
		echo "html { margin-top: 28px !important; }
* html body { margin-top: 28px !important; }";
	}
	echo get_option('custom-adminbar-styles');
	echo '</style>';
}

function cab_bump_override(){
?>
<style>
	html { margin-top: 0 !important; }
	* html body { margin-top: 0 !important; }
</style>
<?php
}

function cab_hide_by_page(){
	$pages = cab_get_disabled_pages();
	$current_object = get_queried_object();
	if ( empty($current_object) )
		return;
		
	if ( in_array($current_object->ID, $pages) ) {
		cab_bump_override();
		cab_unshow_adminbar();
	}
}

function cab_get_disabled_pages(){
	$disabled_pages = $_SESSION['cab_disabled_pages'];
	return $disabled_pages;
}

function cab_add_disabled_page($page){
	if(!isset($_SESSION['cab_disabled_pages']))
		$_SESSION['cab_disabled_pages'] = array();
	
	if(!in_array($page, $_SESSION['cab_disabled_pages']))
		array_push($_SESSION['cab_disabled_pages'], $page);
}

function cab_hide_by_users(){
	$users = cab_get_disabled_users();
	foreach($users as $user){
		if ( current_user_can( $user ) ) {
			cab_unshow_adminbar();
		}
	}
}

function cab_get_disabled_users(){
	$subscriber = get_option('custom-adminbar-subscriber');
	$author = get_option('custom-adminbar-author');
	$contributor = get_option('custom-adminbar-contributor');
	$editor = get_option('custom-adminbar-editor');
	$admin = get_option('custom-adminbar-administrator');
	
	$users = array();
	
	if($subscriber != 'on')
		array_push($users, 'subscriber');
	if($author != 'on')
		array_push($users, 'author');
	if($contributor != 'on')
		array_push($users, 'contributor');
	if($editor != 'on')
		array_push($users, 'editor');
	if($admin != 'on')
		array_push($users, 'administrator');
	
	return $users;
}

function cab_define_callback(){
	add_theme_support( 'admin-bar', array( 'callback' => 'cab_custom_callback') );
}

function cab_disable_adminbar(){
	remove_action('init','wp_admin_bar_init');remove_filter('init','wp_admin_bar_init');foreach(array('wp_footer','wp_admin_bar_render')as$filter);add_action($filter,'wp_admin_bar_render',1000);foreach(array('wp_footer','wp_admin_bar_render')as$filter)add_action($filter,'wp_admin_bar_render',1000);remove_action('wp_head','wp_admin_bar_render',1000);remove_filter('wp_head','wp_admin_bar_render',1000);remove_action('wp_footer','wp_admin_bar_render',1000);remove_filter('wp_footer','wp_admin_bar_render',1000);remove_action('admin_head','wp_admin_bar_render',1000);remove_filter('admin_head','wp_admin_bar_render',1000);remove_action('admin_footer','wp_admin_bar_render',1000);remove_filter('admin_footer','wp_admin_bar_render',1000);remove_action('wp_before_admin_bar_render','wp_admin_bar_me_separator',10);remove_action('wp_before_admin_bar_render','wp_admin_bar_my_account_menu',20);remove_action('wp_before_admin_bar_render','wp_admin_bar_my_blogs_menu',30);remove_action('wp_before_admin_bar_render','wp_admin_bar_blog_separator',40);remove_action('wp_before_admin_bar_render','wp_admin_bar_bloginfo_menu',50);remove_action('wp_before_admin_bar_render','wp_admin_bar_edit_menu',100);remove_action('wp_head','wp_admin_bar_css');remove_action('wp_head','wp_admin_bar_dev_css');remove_action('wp_head','wp_admin_bar_rtl_css');remove_action('wp_head','wp_admin_bar_rtl_dev_css');remove_action('admin_head','wp_admin_bar_css');remove_action('admin_head','wp_admin_bar_dev_css');remove_action('admin_head','wp_admin_bar_rtl_css');remove_action('admin_head','wp_admin_bar_rtl_dev_css');remove_action('wp_footer','wp_admin_bar_js');remove_action('wp_footer','wp_admin_bar_dev_js');remove_action('admin_footer','wp_admin_bar_js');remove_action('admin_footer','wp_admin_bar_dev_js');remove_action('wp_ajax_adminbar_render','wp_admin_bar_ajax_render');remove_action('personal_options',' _admin_bar_preferences');remove_filter('personal_options',' _admin_bar_preferences');remove_action('personal_options',' _get_admin_bar_preferences');remove_filter('personal_options',' _get_admin_bar_preferences');remove_action('personal_options',$profileuser);remove_filter('personal_options',$profileuser);remove_action('personal_options',$profileuser->ID);remove_filter('personal_options',$profileuser->ID);remove_action('profile_personal_options',$profileuser);remove_filter('profile_personal_options',$profileuser);remove_filter('locale','wp_admin_bar_lang');add_filter('show_admin_bar','__return_false');
}

function cab_unshow_adminbar(){
	add_filter('show_admin_bar','__return_false');
}
?>