=== Plugin Name ===

Contributors:      Wesley Todd
Plugin Name:       WP Custom Admin Bar
Plugin URI:        http://wesleytodd.com/?custom-plugin=admin-bar-control
Tags:              Admin Bar, Customize Admin Bar, User Controls, removal, hide, disable, User Role, Roles
Author URI:        http://wesleytodd.com
Author:            Wesley Todd
Requires at least: 3.1
Tested up to:      3.1
Stable tag:        trunk
Version:           1.0
Donate link:	   http://wesleytodd.com/contact

== Description ==

A really simple and easy to use plugin to help gain control of the new Admin Bar.  This gives you options to change who sees the Admin Bar based on their user role, change or override the default styling and remove the Admin Bar altogether.

== Installation ==

1. Extract 'wp-custom-admin-bar' and transfer it to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Visit the setting page to customize your admin bar

== Frequently Asked Questions ==

= Can I disable the Admin Bar for just one browsing session or on just one spicific page? =

Yes you can! As of version 1.0 there is a menu item in the admin bar to disable the bar on a page by page basis or for the entire site.  This setting is for a single browser session, so if you close your browser the settings reset.

For any other questions:
[Contact Me](http://wesleytodd.com/contact)

== Upgrade Notice ==


== Screenshots ==

1. The Administration Options Page.

== Changelog ==

= 1.0 =
* Admin Bar Menu - Session based disabling for whole site or single page

== Donations ==

