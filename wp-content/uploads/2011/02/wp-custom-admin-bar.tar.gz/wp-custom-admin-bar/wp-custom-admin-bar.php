<?php
/*
Plugin Name: WP Custom Admin Bar
Plugin URI: http://wesleytodd.com/?custom-plugin=admin-bar-control
Description: Added control of your Admin Bar. Disable it, show it to certian user levels and modify the styling.
Author: Wes Todd
Version: 0.1
Author URI: http://wesleytodd.com
*/

require_once 'custom-admin-bar-admin.php';
require_once 'custom-admin-bar-functions.php';
?>